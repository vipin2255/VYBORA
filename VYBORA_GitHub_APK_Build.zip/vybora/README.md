# VYBORA Android project

## Build an APK with GitHub Actions
1. Create a GitHub repository (choose Private if you prefer).
2. Upload the contents of this folder to the repository root (not the ZIP file itself).
3. Open the repository's **Actions** tab and allow workflows if GitHub asks.
4. Select **Build VYBORA APK** → **Run workflow**.
5. When the run finishes successfully, open it and download the **VYBORA-debug-APK** artifact.
6. Extract the downloaded artifact ZIP; it contains `app-debug.apk`. Transfer it to your Android phone and install it.

This creates a debug APK for testing, not a Play Store release. The current project is a basic WebView wrapper around the bundled `index.html`; features that need a real backend (accounts, cloud database, admin video upload, etc.) are not production-ready yet.
